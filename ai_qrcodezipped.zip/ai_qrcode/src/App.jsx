import AIQRGenerator from './components/AIQRGenerator';

function App() {
  return (
    <div className="App">
      <AIQRGenerator />
    </div>
  );
}

export default App;